/********************************************************************************/
/**
 ** \file       ipd_custom_definitions.h
 ** \brief      Customer specific settings.
 **/
/********************************************************************************/

#ifndef __IPOQUE_DECODER_PUBLIC_CUSTOM_DEFINITIONS_INCLUDE_FILE__
#define __IPOQUE_DECODER_PUBLIC_CUSTOM_DEFINITIONS_INCLUDE_FILE__

#ifndef __IPOQUE_DECODER_INCLUDE_FILE__
#error please include ipd.h instead of this file
#endif

// #define IPD_DEBUG_MODE


#endif                          /* __IPOQUE_DECODER_PUBLIC_CUSTOM_DEFINITIONS_INCLUDE_FILE__ */
