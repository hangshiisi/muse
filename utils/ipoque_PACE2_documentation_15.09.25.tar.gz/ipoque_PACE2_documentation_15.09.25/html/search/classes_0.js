var searchData=
[
  ['dissector_5fconfig',['dissector_config',['../structdissector__config.html',1,'']]],
  ['dissector_5fresult',['dissector_result',['../uniondissector__result.html',1,'']]]
];
