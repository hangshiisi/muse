var searchData=
[
  ['global_5fepol',['global_epol',['../struct_p_a_c_e2__config__general_1_1global__epol.html',1,'PACE2_config_general']]]
];
