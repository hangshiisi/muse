var searchData=
[
  ['metadata_5fstring',['metadata_string',['../structmetadata__string.html',1,'']]]
];
