var searchData=
[
  ['codec_5flist',['CODEC_LIST',['../ipq__metadata__public_8h.html#a0d056ca471f4579b428b895b70df6efa',1,'ipq_metadata_public.h']]]
];
