var searchData=
[
  ['generate_5fenum',['GENERATE_ENUM',['../pace2__basic__def_8h.html#a5cae422922f07cd98cca3b808bf32a55',1,'pace2_basic_def.h']]],
  ['generate_5fstring',['GENERATE_STRING',['../pace2__basic__def_8h.html#a4cf057ab3bbcea574c6660a326a2d413',1,'pace2_basic_def.h']]]
];
