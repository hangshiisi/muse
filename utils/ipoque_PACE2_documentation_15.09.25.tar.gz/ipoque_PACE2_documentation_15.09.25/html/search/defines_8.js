var searchData=
[
  ['skype_5fvoice_5fdetection',['SKYPE_VOICE_DETECTION',['../ipq__protocols__default_8h.html#a353de4b206346098f862addd7cc891fa',1,'ipq_protocols_default.h']]],
  ['stream_5ftype_5flist',['STREAM_TYPE_LIST',['../ipq__metadata__public_8h.html#a14dd5c1f3129b2b3fbcf13ecaef45f54',1,'ipq_metadata_public.h']]]
];
