var searchData=
[
  ['voip_5fcall_5fstatus_5fnames',['VOIP_CALL_STATUS_NAMES',['../ipd__class__voip__definitions_8h.html#a43efd8853da4d5da200edb472ba532e7',1,'ipd_class_voip_definitions.h']]]
];
