var searchData=
[
  ['codec_5ftype',['codec_type',['../ipq__metadata__public_8h.html#a9ccc15cf8702f80287f7975245fb4d00',1,'ipq_metadata_public.h']]]
];
