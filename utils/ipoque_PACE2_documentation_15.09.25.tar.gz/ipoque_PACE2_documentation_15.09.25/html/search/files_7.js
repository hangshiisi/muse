var searchData=
[
  ['jabber_5fevents_2eh',['jabber_events.h',['../jabber__events_8h.html',1,'']]]
];
