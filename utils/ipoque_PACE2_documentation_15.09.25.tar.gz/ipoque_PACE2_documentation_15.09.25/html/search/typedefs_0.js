var searchData=
[
  ['ipoque_5fclass_5fdecoder_5fbitmask',['IPOQUE_CLASS_DECODER_BITMASK',['../ipd__public__structures_8h.html#a47e290b648ef0e93accdfe5dd001483a',1,'ipd_public_structures.h']]],
  ['ipoque_5fdebug_5ffunction_5fptr',['ipoque_debug_function_ptr',['../ipq__public__functions_8h.html#ab6b9d1bd0c950a594bed63c7e5f150c0',1,'ipq_public_functions.h']]],
  ['ipoque_5fparo_5fcallback_5fext',['ipoque_paro_callback_ext',['../ipq__paro_8h.html#aeac2c73a29fb21b307ccb67227787436',1,'ipq_paro.h']]],
  ['ipoque_5fpostproc_5fprotocol_5fbitmask',['IPOQUE_POSTPROC_PROTOCOL_BITMASK',['../ipd__public__structures_8h.html#aa3185330c1e72b3b97d75dd67c4e894b',1,'ipd_public_structures.h']]]
];
